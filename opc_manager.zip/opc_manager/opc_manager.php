<?php

use WHMCS;
use WHMCS\Database\Capsule;
use WHMCS\Module\Addon\OpcManager\Admin\AdminDispatcher;
use WHMCS\Module\Addon\OpcManager\Client\ClientDispatcher;

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

function opc_manager_config()
{
    return [
        // Display name for your module
        'name' => 'OPC Manager',
        // Description displayed within the admin interface
        'description' => 'This addon provide you the access to control the One Step Checkout features.',
        // Module author name
        'author' => '<a href=\"http://whmcsglobalservices.com/\" target=\"_blank\">WHMCS GLOBAL SERVICES</a>',
        // Default language
        'language' => 'english',
        // Version number
        'version' => '1.0',
        "fields" => [
            "license_key" => array("FriendlyName" => "License key", "Type" => "text", "Size" => "50"),
            "delete_db" => array("FriendlyName" => "Delete Database Table", "Type" => "yesno", "Default" => "yes", "Description" => "Tick this box to delete the addon module database table when deactivating the module."),
        ]
    ];
}

function opc_manager_activate()
{
    // Create custom tables and schema required by your module
    try {
        return [
            // Supported values here include: success, error or info
            'status' => 'success',
            'description' => 'This is a demo module only. '
                . 'In a real module you might report a success or instruct a '
                    . 'user how to get started with it here.',
        ];
    } catch (\Exception $e) {
        return [
            // Supported values here include: success, error or info
            'status' => "error",
            'description' => 'Unable to create mod_addonexample: ' . $e->getMessage(),
        ];
    }
}

function opc_manager_deactivate()
{
    // Undo any database and schema modifications made by your module here
    try {
    
        return [
            // Supported values here include: success, error or info
            'status' => 'success',
            'description' => 'This is a demo module only. '
                . 'In a real module you might report a success here.',
        ];
    } catch (\Exception $e) {
        return [
            // Supported values here include: success, error or info
            "status" => "error",
            "description" => "Unable to drop mod_addonexample: {$e->getMessage()}",
        ];
    }
}

function opc_manager_output($vars)
{
    $whmcs = WHMCS\Application::getInstance();
    $action = !empty($whmcs->get_req_var("action")) ? $whmcs->get_req_var("action") : 'dasboard';
    $dispatcher = new AdminDispatcher();
    $dispatcher->dispatch($action, $vars);
}

function opc_manager_clientarea($vars)
{
    $vars['module'] = 'OPC Manager';
    $whmcs = WHMCS\Application::getInstance();
    $action = !empty($whmcs->get_req_var("action")) ? $whmcs->get_req_var("action") : 'clientdasboard';
    $dispatcher = new ClientDispatcher();
    return $dispatcher->dispatch($action, $vars);
}
