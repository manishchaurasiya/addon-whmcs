<?php

namespace WHMCS\Module\Addon\OpcManager\Client;

/**
 * Sample Client Area Dispatch Handler
 */
class ClientDispatcher {

    /**
     * Dispatch request.
     *
     * @param string $action
     * @param array $parameters
     *
     * @return array
     */
    public function dispatch($action, $parameters)
    {
        $controller = new Controller($parameters);

        if (is_callable(array($controller, $action))) {
            return $controller->$action();
        }

        return '<p>Invalid action requested. Please go back and try again.</p>';
        }
    }
