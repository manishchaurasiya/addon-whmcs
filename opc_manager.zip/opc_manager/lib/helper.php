<?php

namespace WHMCS\Module\Addon\OpcManager;

use WHMCS\Database\Capsule;


class Helper
{

}

?>