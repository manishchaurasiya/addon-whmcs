<?php

namespace WHMCS\Module\Addon\OpcManager\Admin;

use getData;
use WHMCS\Module\Addon\OpcManager\Helper;
use WHMCS\Database\Capsule;
use Smarty;

require_once __DIR__ . '/../helper.php';
/**
 * Sample Admin Area Controller
 */
class Controller
{

    public $tplFileName;
    public $tplDIR;
    public $smarty;
    public $tplVar = array();

    public function __construct($params)
    {
        global $CONFIG;

        $this->params = $params;
        $this->tplVar['rootURL'] = $CONFIG["SystemURL"];
        $this->tplVar['urlPath'] = $CONFIG["SystemURL"] . "/modules/addons/{$params['module']}/";
        $this->tplVar['_lang'] = $params["_lang"];
        $this->tplVar['moduleLink'] = $params['modulelink'];
        $this->tplVar['module'] = $params['module'];
        $this->tplVar['tplDIR'] = ROOTDIR . "/modules/addons/{$params['module']}/templates/admin/";
        $this->tplVar['header'] = ROOTDIR . "/modules/addons/{$params['module']}/templates/admin/header.tpl";
        $this->tplVar['footer'] = ROOTDIR . "/modules/addons/{$params['module']}/templates/admin/footer.tpl";
    }
    public function dasboard()
    {
        $this->tplFileName = __FUNCTION__;
        $this->output();
    }

    public function setting()
    {
        $this->tplFileName = __FUNCTION__;
        $this->output();
    }

    public function output($data = null)
    {
        $this->tplVar['data'] = $data;
        $this->smarty = new Smarty();
        $this->smarty->assign('tplVar', $this->tplVar);
        if (!empty($this->tplFileName)) {
            $this->smarty->display($this->tplVar['tplDIR'] . $this->tplFileName . '.tpl');
        } else {
            $this->templateVar['errorMsg'] = 'not found'; //$this->tplVar['_lang']['admin']['template']["error"];
            $this->smarty->display($this->tplDIR . 'error.tpl');
        }
    }

}
