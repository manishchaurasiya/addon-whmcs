<?php
/**
 * Sample addon module language file.
 * Language: English
 */
$_ADDONLANG['variable_name'] = "Translated language string.";
$_ADDONLANG['navbar_setting'] = "Settings";
$_ADDONLANG['navbar_dasboard'] = "Home";
$_ADDONLANG['settings']["table_disable_geolocation"] = "Disable Geolocation";
$_ADDONLANG['settings']["table_disable_geolocation_desc"] = "This will disable geolocation and gateway hide show will work according to country change from checkout form.";
$_ADDONLANG['settings']["table_disable_name_server"] = "Disable Name Server";
$_ADDONLANG['settings']["table_disable_name_server_desc"] = "Disable Name Server Section From Page";
$_ADDONLANG['settings']["table_move_domain_section"] = "Move Domain Section";
$_ADDONLANG['settings']["table_move_domain_section_desc"] = "Move Domain Section Under Product Plans";
$_ADDONLANG['settings']["table_disable_currency_changer"] = "Disable Currency Changer";
$_ADDONLANG['settings']["table_disable_currency_changer_desc"] = "Disable the currency changer on the order form";
$_ADDONLANG['settings']["table_hide_all_products_plans"] = "Hide All Products And Plans";
$_ADDONLANG['settings']["table_hide_all_products_plans_desc"] = "Hide all products and plans when product is added via query string";
$_ADDONLANG['settings']["table_enable_shortest_billing_cycle"] = "Enable Shortest Billing Cycle";
$_ADDONLANG['settings']["table_enable_shortest_billing_cycle_desc"] = "Enable Shortest Billing Cycle By Default in Product Listing";
$_ADDONLANG['settings']["table_product_id"] = "Product ID";
$_ADDONLANG['settings']["table_product_id_desc"] = "Static Product ID for Stripe Payment Gateway";
